<?php 

require "./db/db.php";

if(isset($_POST["categories"]) && isset($_POST["type_categories"]) && isset($_POST["categories_product"])) {
    $categories = $_POST["categories"];
    $type_categories = $_POST["type_categories"];
    $categories_product = $_POST["categories_product"];
    $number = rand(111111111111,9999999999999999);
    $query = $pdo->prepare("INSERT INTO `categories_product`(`text`, `callback_data`, `categories_key`, `product_key`) VALUES (?,?,?,?)");
    $query->execute([$categories_product, $categories, $type_categories, $number]);
    echo "<script>alert('Добавленно')</script>";
}

if(isset($_POST["delete"])) {
    $delete = $_POST["delete"];
    $query = $pdo->prepare("DELETE FROM `categories_product` WHERE `id` = ?");
    $query->execute([$delete]);
    echo "<script>alert('Удаленно')</script>";
}



function allQuery() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data` FROM `categories` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

function allQuery2() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data`, `categories_key` FROM `type_categories` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

function allQuery3() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data`, `categories_key`, `product_key` FROM `categories_product` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

$categories = allQuery();
$type_categories = allQuery2();
$categories_product = allQuery3();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>categories_product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a class="btn btn-primary" href="index.php">Назад</a>

    <form action="" method="POST">
        <select name="categories">
            <?php
            for ($i=0; $i < count($categories); $i++) { 
                
            ?>
            <option value="<?= $categories[$i]['callback_data'] ?>"><?= $categories[$i]['text'] ?></option>
            <?php } ?>
        </select>
        <select name="type_categories">
            <?php
            for ($i=0; $i < count($type_categories); $i++) { 
                
            ?>
            <option value="<?= $type_categories[$i]['categories_key'] ?>"><?= $type_categories[$i]['text'] ?></option>
            <?php } ?>
        </select>
        <input type="text" name="categories_product" placeholder="Название типа товара">
        <button class="btn btn-success">Добавить</button>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>№</th>
                <th>Категория</th>
                <th>ид под категории</th>
                <th>ключ типа товара</th>
                <th>ключ товара</th>
                <th>Кнопка</th>
            </tr>
        </thead>
        <tbody>
           <?php
           
           for( $i = 0; $i < count($categories_product); $i++ ) {
            
           ?>
           <tr>
            <td><?= $categories_product[$i]["id"]; ?></td>
            <td><?= $categories_product[$i]["text"]; ?></td>
            <td><?= $categories_product[$i]["callback_data"]; ?></td>
            <td><?= $categories_product[$i]["categories_key"]; ?></td>
            <td><?= $categories_product[$i]["product_key"]; ?></td>
            <td>
                <form action="" method="POST">
                    <input 
                        name="delete" 
                        style="position: absolute; top: -1000px;" 
                        type="text" 
                        value="<?= $categories_product[$i]["id"]; ?>">
                    <button class="btn btn-danger">Удалить</button>
                </form>
            </td>
           </tr>
           <?php } ?>
        </tbody>
    </table>
    <script>
        let password = localStorage.getItem('password')

        if(password == 'qDFr5c_W8m') {} else {
            location.href = "/"
        }
    </script>
    
</body>
</html>