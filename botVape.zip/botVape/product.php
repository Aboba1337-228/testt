<?php 

require "./db/db.php";

if(isset($_POST["url"]) && isset($_POST["name_product"]) && isset($_POST["name_description"]) && isset($_POST["categories_product"]) && isset($_POST["price"])) {
    $categories_product = $_POST["categories_product"];
    $url = $_POST["url"];
    $name_product = $_POST["name_product"];
    $name_description = $_POST["name_description"];
    $price = $_POST["price"];
    $query = $pdo->prepare("INSERT INTO `product`(`image`, `name`, `descript`, `price`, `key`) VALUES (?,?,?,?,?)");
    $query->execute([$url, $name_product, $name_description, $price, $categories_product]);
    echo "<script>alert('Добавленно')</script>";
}

if(isset($_POST["delete"])) {
    $delete = $_POST["delete"];
    $query = $pdo->prepare("DELETE FROM `product` WHERE `id` = ?");
    $query->execute([$delete]);
    echo "<script>alert('Удаленно')</script>";
}



function allQuery() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data`, `categories_key`, `product_key` FROM `categories_product` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

function allProduct() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `image`, `name`, `descript`, `price`, `key` FROM `product` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}


$categories_product = allQuery();
$product = allProduct();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>categories_product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a class="btn btn-primary" href="index.php">Назад</a>

    <form action="" method="POST">
        <select name="categories_product">
            <?php
            for ($i=0; $i < count($categories_product); $i++) { 
                
            ?>
            <option value="<?= $categories_product[$i]['product_key'] ?>"><?= $categories_product[$i]['text'] ?></option>
            <?php } ?>
        </select>
        <input type="text" name="url" placeholder="url Картинка">
        <input type="text" name="name_product" placeholder="Название товара">
        <input type="text" name="name_description" placeholder="Описание товара">
        <input type="text" name="price" placeholder="Цена">
        <button class="btn btn-success">Добавить</button>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>№</th>
                <th>Картинка</th>
                <th>имя товара</th>
                <th>Описание</th>
                <th>Цена</th>
                <th>Ключ</th>
                <th>Кнопки</th>
            </tr>
        </thead>
        <tbody>
           <?php
           
           for( $i = 0; $i < count($product); $i++ ) {
            
           ?>
           <tr>
            <td><?= $product[$i]["id"]; ?></td>
            <td><?= $product[$i]["image"]; ?></td>
            <td><?= $product[$i]["name"]; ?></td>
            <td><?= $product[$i]["descript"]; ?></td>
            <td><?= $product[$i]["price"]; ?></td>
            <td><?= $product[$i]["key"]; ?></td>
            <td>
                <form action="" method="POST">
                    <input 
                        name="delete" 
                        style="position: absolute; top: -1000px;" 
                        type="text" 
                        value="<?= $product[$i]["id"]; ?>">
                    <button class="btn btn-danger">Удалить</button>
                </form>
            </td>
           </tr>
           <?php } ?>
        </tbody>
    </table>
    <script>
        let password = localStorage.getItem('password')

        if(password == 'qDFr5c_W8m') {} else {
            location.href = "/"
        }
    </script>
    
</body>
</html>