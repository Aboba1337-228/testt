<?php 

require "./db/db.php";

if(isset($_POST["categories"])) {
    $categories = $_POST["categories"];
    $number = rand(111111111111,9999999999999999);
    $query = $pdo->prepare("INSERT INTO `categories`(`text`, `callback_data`) VALUES (?,?)");
    $query->execute([$categories, $number]);
    echo "<script>alert('Добавленно')</script>";
}

if(isset($_POST["delete"])) {
    $delete = $_POST["delete"];
    $query = $pdo->prepare("DELETE FROM `categories` WHERE `id` = ?");
    $query->execute([$delete]);
    echo "<script>alert('Удаленно')</script>";
}

function allQuery() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data` FROM `categories` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

$categories = allQuery();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a class="btn btn-primary" href="index.php">Назад</a>

    <form action="" method="POST">
        <input type="text" name="categories" placeholder="Название под категории">
        <button class="btn btn-success">Добавить</button>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>№</th>
                <th>Категория</th>
                <th>ид под категории</th>
                <th>Кнопка</th>
            </tr>
        </thead>
        <tbody>
           <?php
           
           for( $i = 0; $i < count($categories); $i++ ) {
            
           ?>
           <tr>
            <td><?= $categories[$i]["id"]; ?></td>
            <td><?= $categories[$i]["text"]; ?></td>
            <td><?= $categories[$i]["callback_data"]; ?></td>
            <td>
                <form action="" method="POST">
                    <input 
                        name="delete" 
                        style="position: absolute; top: -1000px;" 
                        type="text" 
                        value="<?= $categories[$i]["id"]; ?>">
                    <button class="btn btn-danger">Удалить</button>
                </form>
            </td>
           </tr>
           <?php } ?>
        </tbody>
    </table>
    <script>
        let password = localStorage.getItem('password')

        if(password == 'qDFr5c_W8m') {} else {
            location.href = "/"
        }
    </script>
    
</body>
</html>