<?php 

require "./db/db.php";

if(isset($_POST["categories"]) && isset($_POST["type_categories"])) {
    $categories = $_POST["categories"];
    $type_categories = $_POST["type_categories"];
    $number = rand(111111111111,9999999999999999);
    $query = $pdo->prepare("INSERT INTO `type_categories`(`text`, `callback_data`,`categories_key`) VALUES (?,?,?)");
    $query->execute([$type_categories, $categories, $number]);
    echo "<script>alert('Добавленно')</script>";
}

if(isset($_POST["delete"])) {
    $delete = $_POST["delete"];
    $query = $pdo->prepare("DELETE FROM `type_categories` WHERE `id` = ?");
    $query->execute([$delete]);
    echo "<script>alert('Удаленно')</script>";
}



function allQuery() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data` FROM `categories` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

function allQuery2() {
    global $pdo;

    $query = $pdo->prepare("SELECT `id`, `text`, `callback_data`, `categories_key` FROM `type_categories` WHERE 1");
    $query->execute();
    $response = $query->fetchAll();

    return $response;
}

$categories = allQuery();
$type_categories = allQuery2();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>type_categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <a class="btn btn-primary" href="index.php">Назад</a>

    <form action="" method="POST">
        <select name="categories">
            <?php
            for ($i=0; $i < count($categories); $i++) { 
                
            ?>
            <option value="<?= $categories[$i]['callback_data'] ?>"><?= $categories[$i]['text'] ?></option>
            <?php } ?>
        </select>
        <input type="text" name="type_categories" placeholder="Название под категории">
        <button class="btn btn-success">Добавить</button>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>№</th>
                <th>Категория</th>
                <th>ид под категории</th>
                <th>ключ типа товара</th>
                <th>Кнопка</th>
            </tr>
        </thead>
        <tbody>
           <?php
           
           for( $i = 0; $i < count($type_categories); $i++ ) {
            
           ?>
           <tr>
            <td><?= $type_categories[$i]["id"]; ?></td>
            <td><?= $type_categories[$i]["text"]; ?></td>
            <td><?= $type_categories[$i]["callback_data"]; ?></td>
            <td><?= $type_categories[$i]["categories_key"]; ?></td>
            <td>
                <form action="" method="POST">
                    <input 
                        name="delete" 
                        style="position: absolute; top: -1000px;" 
                        type="text" 
                        value="<?= $type_categories[$i]["id"]; ?>">
                    <button class="btn btn-danger">Удалить</button>
                </form>
            </td>
           </tr>
           <?php } ?>
        </tbody>
    </table>
    <script>
        let password = localStorage.getItem('password')

        if(password == 'qDFr5c_W8m') {} else {
            location.href = "/"
        }
    </script>
    
</body>
</html>