<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>botADD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div style="margin: 10px;">
        <a class="btn btn-primary" href="categories.php">Категории</a>
        <a class="btn btn-primary" href="type_categories.php">Под категории</a>
        <a class="btn btn-primary" href="categories_product.php">Тип товара</a>
        <a class="btn btn-primary" href="product.php">Товар</a>
    </div>

    <script>
        let password = localStorage.getItem('password')

        if(password == 'qDFr5c_W8m') {} else {
            location.href = "/"
        }
    </script>
</body>
</html>